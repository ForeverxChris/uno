package com.example.unogroupproject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class example_driver {

    private static initDeck deck;
    private static List<Card> discard = new ArrayList<>();
    private static List<Player> playerList = new ArrayList<>();
    private static int playerCounter;

    public static void main(String[] args) {
        deck = new initDeck();
        // initialize deck object

        // noah - give remove draw// brandon cpu play //sam player win check

        deck.shuffle();
        // optional shuffle

        // for (Card card : deck.getDeck()) { System.out.println(card); }


//        for (Player player : players) {
//            System.out.println(player.getName());
//            System.out.println(player.getHand());
//        }

        discard.add(deck.drawCard());

        playerList.add(new Player("user"));
        playerList.add(new Player("cpu"));



        for (Player player : playerList) {
            for (int i=0; i<7; i++) {
                player.addCard(deck.drawCard());
            }
        }

        playerCounter = 0;
        Player currentPlayer = playerList.get(playerCounter%2);

//        while (!currentPlayer.hasWon()) {
//            if (playerCounter%2 == 0) {
//
//            } else {
//
//            }
//            playerCounter++;
//        }

//        while (!currentPlayer.hasWon()) {
//            System.out.printf("%s size: %d%s\n", currentPlayer.getName(), currentPlayer.getHand().size(), currentPlayer.getHand());
//            int cardCount = 0;
//            while (cardCount<currentPlayer.getHand().size()-1) {
//                Card card = currentPlayer.getHand().get(cardCount);
//                if (card.canBePlayedOn(discard.get(discard.size() - 1))) {
//                    discard.add(currentPlayer.playCard(card));
//                    break;
//                }
//                cardCount++;
//            } if (cardCount==currentPlayer.getHand().size()-1) {
//                currentPlayer.addCard(deck.drawCard());
//            }
//            currentPlayer = players.get((playerCounter++)%2);
//            if (deck.isEmpty()) {
//                ArrayList<Card> discard_deck = new ArrayList<>();
//                discard_deck.add(discard.remove(discard.size()-1));
////                System.out.println(discard_deck.size());
//                deck.setDeck(discard);
//                discard = discard_deck;
//            }
//            System.out.println(discard);
//            System.out.println(discard.size());
//            System.out.println(deck.isEmpty());
//        }
    }

    public int getPlayerCounter() {
        return playerCounter;
    }

    public Player getUserPlayer() {
        return playerList.get(0);
    }

    public Player getCpuPlayer() {
        return playerList.get(1);
    }

    public initDeck getDeck() {
        return deck;
    }

    public List<Card> getDiscard() {
        return discard;
    }
}